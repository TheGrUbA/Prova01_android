package com.example.aluno.prova01;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btnMais;
    Button btnMenos;
    Button btnZera;
    TextView contador;
    int cont = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnMais = findViewById(R.id.botaoMais);
        btnMenos = findViewById(R.id.botaoMenos);
        btnZera = findViewById(R.id.botaoZera);
        contador = findViewById(R.id.contador);

        btnMais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cont++;
                MudaValor(String.valueOf(cont));
                MudaCor("azul");
            }
        });

        btnMenos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cont--;
                MudaValor(String.valueOf(cont));
                MudaCor("vermelho");
            }
        });

        btnZera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cont = 0;
                MudaValor(String.valueOf(cont));
                MudaCor("verde");
            }
        });
    }

    private void MudaValor(String valor){
        contador.setText(valor);
    }

    private void MudaCor(String valor){
        if(valor.equals("vermelho"))
            contador.setBackgroundColor(Color.RED);
        if(valor.equals("verde"))
            contador.setBackgroundColor(Color.GREEN);
        if(valor.equals("azul"))
            contador.setBackgroundColor(Color.BLUE);
    }
}
